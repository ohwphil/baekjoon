#include <cstdio>
#define MAX_ELEMENT 200
class MaxPriorityQueue{
    int elem[MAX_ELEMENT];
    int size;
public:
    MaxPriorityQueue():size(0){}
    void insert(int e){
        int place=0;
        while(place<size){
            if(e>=elem[place]) break;
            ++place;
        }
        for(int i=size;i>place;i--){//�ε�ȣ ����!
            elem[i]=elem[i-1];
        }
        elem[place]=e;
        ++size;
    }
    int remove(){
        int temp=elem[0];
        size--;
        for(int i=1;i<=size;i++){
            elem[i-1]=elem[i];
        }
        return temp;
    }
    int find(){
        return elem[0];
    }
    void display(){
        for(int i=0;i<size;i++){
            printf("%d ", elem[i]);
        }
        printf("\n");
    }
};
int main(){
    MaxPriorityQueue q;
    q.insert(2);
    q.display();
    q.insert(3);
    q.display();
}
