#include <cstdio>
class Node{
    int key;
    Node* link;
public:
    Node(int k=0, Node *l=NULL) : key(k), link(l){}
    int getKey(){return key;}
    void setKey(int k){key=k;}
    Node *getLink(){return link;}
    void setLink(Node *l){link=l;}
    void display(){printf("%d ", key);}
};
class MinPriorityQueue{
    Node* min;
    int size;
public:
    MinPriorityQueue() : min(NULL), size(0){}
    void insert(Node *n){
        Node *prev=NULL;
        Node *next=min;
        for(; next!=NULL; prev=next, next=next->getLink()){
            if(n->getKey()<=next->getKey()) break;
        }
        if(n!=NULL) n->setLink(next);
        if(prev!=NULL) prev->setLink(n);
        if(min==NULL || min->getKey()>=n->getKey()) min=n;//min�� ������Ʈ�ϴ� �ڵ� �ʿ�!
        ++size;
    }
    Node *remove(){
        Node *temp = min;
        min=min->getLink();
        --size;
        return temp;//return temp!
    }
    Node *find(){return min;}
    void display(){
        for(Node *curr = min;curr!=NULL;curr=curr->getLink()){
            curr->display();
        }
        printf("\n");
    }
};
int main(){
    MinPriorityQueue q;
    q.insert(new Node(3));
    q.insert(new Node(2));
    q.insert(new Node(2));
    q.display();
}
