#include <cstdio>
bool isHeapRecur(int a[], int size, int curr){
    if(curr*2>size) return true;
    if(a[curr]<a[curr*2]) return false;
    if(curr*2+1<=size){
        if(a[curr]<a[curr*2+1]) return false;
    }
    return isHeapRecur(a, size, curr*2) && isHeapRecur(a, size, curr*2+1);
}
bool isHeapRecur(int a[], int size){
    return isHeapRecur(a, size, 1);
}
bool isHeapIter(int a[], int size){
    for(int i=1;i<=size/2;i++){
        if(a[i]<a[i*2]) return false;
        if(i*2+1<=size){
            if(a[i]<a[i*2+1]) return false;
        }
    }
    return true;
}
int main(){
    int arr[11] = { 0, 9, 7, 6, 5, 4, 3, 2 , 2, 1, 3 };
    printf("%d %d", isHeapRecur(arr, 10), isHeapIter(arr, 10));
}
